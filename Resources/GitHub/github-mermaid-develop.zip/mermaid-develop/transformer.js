module.exports = require('babel-jest').createTransformer({
  rootMode: 'upward'
})
