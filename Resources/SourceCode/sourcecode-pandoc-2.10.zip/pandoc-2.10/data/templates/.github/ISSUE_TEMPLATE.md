This repository is now maintained as a subtree of
[jgm/pandoc](https://github.com/jgm/pandoc).  Please open
your issue there, not here.
